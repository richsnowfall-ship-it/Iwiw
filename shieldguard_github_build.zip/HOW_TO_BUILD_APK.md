# ShieldGuard — APK Build Kaise Kare (Bina Android Studio Ke)

## Ek baar ka setup (5 minute)

### Step 1 — GitHub Account Banao
- github.com pe jao
- Free account banao

### Step 2 — Naya Repository Banao
- GitHub pe "+" button → "New repository"
- Name: `shieldguard-app`
- Private rakho (important!)
- "Create repository" click karo

### Step 3 — Code Upload Karo
- Repository page pe "uploading an existing file" link dikhe ga
- Is zip ka content extract karke saari files upload karo
- Ya GitHub Desktop app use karo

### Step 4 — APK Build Karo (Har Baar Yahi Karna Hai)
1. GitHub pe apni repository kholo
2. Upar "Actions" tab click karo
3. Left mein "Build ShieldGuard APK" click karo
4. Right mein "Run workflow" button click karo
5. Debug ya Release choose karo → "Run workflow" press karo
6. 5-10 minute wait karo (pehli baar 15 min lag sakte hain)
7. Build complete hone ke baad click karo
8. Niche "Artifacts" section mein APK download karo

## Har Baar Code Change Ke Baad
- Files update karo GitHub pe
- Actions → Run workflow → APK download

## Debug vs Release
- **Debug** — Testing ke liye, seedha phone mein install ho jaata hai
- **Release** — Play Store ke liye (signing certificate chahiye)

## Phone Mein Install Kaise Kare
1. Phone Settings → Security → "Unknown sources" ON karo
2. APK file phone mein transfer karo
3. APK pe tap karo → Install
