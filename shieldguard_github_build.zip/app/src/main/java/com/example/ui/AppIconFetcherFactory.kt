package com.example.ui

import android.content.Context
import android.graphics.drawable.Drawable
import coil.ImageLoader
import coil.decode.DataSource
import coil.fetch.DrawableResult
import coil.fetch.FetchResult
import coil.fetch.Fetcher
import coil.request.Options

/**
 * AppIconFetcherFactory
 *
 * Yah Coil ko batata hai ki AppIconFetcher data class
 * ko kaise handle karna hai.
 *
 * Kaise kaam karta hai:
 * PackageManager se real installed app ka icon drawable leta hai
 * aur Coil pipeline mein inject karta hai —
 * jisse AsyncImage directly real icon dikhata hai.
 */
class AppIconFetcherFactory(private val context: Context) : Fetcher.Factory<AppIconFetcher> {
    override fun create(data: AppIconFetcher, options: Options, imageLoader: ImageLoader): Fetcher? {
        return if (data.packageName != null) {
            AppIconFetcherImpl(context, data.packageName)
        } else {
            null
        }
    }
}

/**
 * Actual fetcher — PackageManager se icon leta hai
 */
class AppIconFetcherImpl(
    private val context: Context,
    private val packageName: String
) : Fetcher {
    override suspend fun fetch(): FetchResult? {
        return try {
            val drawable: Drawable = context.packageManager.getApplicationIcon(packageName)
            DrawableResult(
                drawable = drawable,
                isSampled = false,
                dataSource = DataSource.DISK
            )
        } catch (e: Exception) {
            // App installed nahi hai — null return karo, fallback UI chalega
            null
        }
    }
}
