package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class ParentControlViewModel(private val repository: ParentControlRepository) : ViewModel() {

    // Default children profiles
    val childrenProfiles = listOf(
        ChildProfile("Emily-01", "Emily's phone", "82%", "Active", "Instagram"),
        ChildProfile("Rah-02", "Rahul's phone", "42%", "Idle", "Snapchat"),
        ChildProfile("Aar-03", "Aarav's phone", "12% (Charging)", "Offline", "Home Screen")
    )

    private val _selectedChildId = MutableStateFlow("Emily-01")
    val selectedChildId: StateFlow<String> = _selectedChildId.asStateFlow()

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val logs: StateFlow<List<ActivityLog>> = _selectedChildId
        .flatMapLatest { childId -> repository.getLogsByChild(childId) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val config: StateFlow<DeviceConfig?> = _selectedChildId
        .flatMapLatest { childId -> repository.getConfigByChild(childId) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val screenshots: StateFlow<List<ScreenshotLog>> = _selectedChildId
        .flatMapLatest { childId -> repository.getScreenshotsByChild(childId) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val locations: StateFlow<List<ChildLocation>> = _selectedChildId
        .flatMapLatest { childId -> repository.getLocationsByChild(childId) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeProfile: StateFlow<ChildProfile> = combine(selectedChildId, flowOf(childrenProfiles)) { id, list ->
        list.find { it.id == id } ?: list.first()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), childrenProfiles.first())

    init {
        // Initialize default device configurations and fallback dummy logs if database is blank
        viewModelScope.launch {
            childrenProfiles.forEach { profile ->
                val currentConfig = repository.getConfigDirect(profile.id)
                if (currentConfig == null) {
                    repository.insertOrUpdateConfig(
                        DeviceConfig(
                            childId = profile.id,
                            isPhoneLocked = false,
                            lockedApps = "YouTube,Instagram",
                            isInternetBlocked = false,
                            geofenceLat = 28.6139 + (if (profile.id == "Emily-01") 0.0 else if (profile.id == "Rah-02") 0.005 else -0.004),
                            geofenceLng = 77.2090 + (if (profile.id == "Emily-01") 0.0 else if (profile.id == "Rah-02") -0.003 else 0.006),
                            geofenceRadius = 600f
                        )
                    )
                    
                    // Seed initial location
                    repository.insertLocation(
                        ChildLocation(
                            childId = profile.id,
                            latitude = 28.6139 + (if (profile.id == "Emily-01") 0.0 else if (profile.id == "Rah-02") 0.005 else -0.004),
                            longitude = 77.2090 + (if (profile.id == "Emily-01") 0.0 else if (profile.id == "Rah-02") -0.003 else 0.006)
                        )
                    )
                    
                    // Seed standard screenshot
                    repository.insertScreenshot(
                        ScreenshotLog(
                            childId = profile.id,
                            imageData = "MOCK_HOMESCREEN",
                            appName = "Instagram"
                        )
                    )

                    // Seed standard app activity logs for Emily-01
                    if (profile.id == "Emily-01") {
                        repository.insertLog(
                            ActivityLog(
                                childId = profile.id,
                                type = "APP_USAGE",
                                title = "Instagram",
                                content = "3 Minutes",
                                extra = "5 min ago",
                                timestamp = System.currentTimeMillis() - 5 * 60 * 1000
                            )
                        )
                        repository.insertLog(
                            ActivityLog(
                                childId = profile.id,
                                type = "APP_USAGE",
                                title = "Youtube",
                                content = "30 Minutes",
                                extra = "08:21 AM",
                                timestamp = System.currentTimeMillis() - 4 * 60 * 60 * 1000
                            )
                        )
                        repository.insertLog(
                            ActivityLog(
                                childId = profile.id,
                                type = "APP_USAGE",
                                title = "Tiktok",
                                content = "2 Minutes",
                                extra = "07:21 AM",
                                timestamp = System.currentTimeMillis() - 5 * 60 * 60 * 1000
                            )
                        )
                    } else {
                        // Insert introductory logs
                        repository.insertLog(
                            ActivityLog(
                                childId = profile.id,
                                type = "NOTIFICATION",
                                title = "System Setup",
                                content = "ShieldGuard background security service initialized.",
                                extra = "com.aistudio.shieldguard"
                            )
                        )
                    }
                }
            }
        }
    }

    fun selectChild(childId: String) {
        _selectedChildId.value = childId
    }

    fun deleteLogBy(id: Int) {
        viewModelScope.launch {
            repository.deleteLogBy(id)
        }
    }

    // Remote Configuration Controls
    fun setPhoneLocked(locked: Boolean) {
        viewModelScope.launch {
            val childId = _selectedChildId.value
            val current = repository.getConfigDirect(childId) ?: DeviceConfig(childId = childId)
            repository.insertOrUpdateConfig(current.copy(isPhoneLocked = locked, lastActiveTime = System.currentTimeMillis()))
            repository.insertLog(
                ActivityLog(
                    childId = childId,
                    type = "NOTIFICATION",
                    title = "Remote Phone Lock",
                    content = if (locked) "Guardian locked the child phone screen remotely." else "Guardian unlocked the child phone screen remotely."
                )
            )
        }
    }

    fun setInternetBlocked(blocked: Boolean) {
        viewModelScope.launch {
            val childId = _selectedChildId.value
            val current = repository.getConfigDirect(childId) ?: DeviceConfig(childId = childId)
            repository.insertOrUpdateConfig(current.copy(isInternetBlocked = blocked, lastActiveTime = System.currentTimeMillis()))
            repository.insertLog(
                ActivityLog(
                    childId = childId,
                    type = "NOTIFICATION",
                    title = "Remote Internet Status",
                    content = if (blocked) "Guardian suspended network adapter connectivity." else "Guardian restored full system internet access."
                )
            )
        }
    }

    fun updateLockedApps(appsCommaSeparated: String) {
        viewModelScope.launch {
            val childId = _selectedChildId.value
            val current = repository.getConfigDirect(childId) ?: DeviceConfig(childId = childId)
            repository.insertOrUpdateConfig(current.copy(lockedApps = appsCommaSeparated, lastActiveTime = System.currentTimeMillis()))
        }
    }

    fun updateGeofence(latitude: Double, longitude: Double, radiusMeters: Float) {
        viewModelScope.launch {
            val childId = _selectedChildId.value
            val current = repository.getConfigDirect(childId) ?: DeviceConfig(childId = childId)
            repository.insertOrUpdateConfig(
                current.copy(
                    geofenceLat = latitude,
                    geofenceLng = longitude,
                    geofenceRadius = radiusMeters,
                    lastActiveTime = System.currentTimeMillis()
                )
            )
        }
    }

    fun clearAllLogs() {
        viewModelScope.launch {
            repository.clearLogsByChild(_selectedChildId.value)
            repository.clearScreenshots(_selectedChildId.value)
        }
    }

    // SIMULATOR TRIGGERING FUNCTIONS (Used in the Child Agent Simulator pane)
    fun simulateAppOpened(appName: String, packageName: String) {
        viewModelScope.launch {
            val childId = _selectedChildId.value
            // Check if application is currently locked!
            val currentConfig = repository.getConfigDirect(childId)
            val isAppLocked = currentConfig?.lockedApps?.split(",")?.map { it.trim().lowercase() }?.contains(appName.trim().lowercase()) == true
            
            if (isAppLocked) {
                repository.insertLog(
                    ActivityLog(
                        childId = childId,
                        type = "NOTIFICATION",
                        title = "App Block Blocked",
                        content = "Kid attempted to open locked application: $appName (Access Blocked by Guardian Policy)",
                        extra = packageName
                    )
                )
            } else {
                repository.insertLog(
                    ActivityLog(
                        childId = childId,
                        type = "APP_USAGE",
                        title = appName,
                        content = "App started in foreground. Foreground monitoring hook registered.",
                        extra = packageName
                    )
                )
            }
        }
    }

    fun simulateKeystroke(appName: String, typedText: String) {
        viewModelScope.launch {
            val childId = _selectedChildId.value
            
            // Analyze for dangerous trigger keywords:
            val keywords = listOf("suicide", "kill myself", "hate myself", "meet secretly", "dont tell parents", "run away")
            val containsDangerousKeyword = keywords.any { typedText.lowercase().contains(it) }

            if (containsDangerousKeyword) {
                repository.insertLog(
                    ActivityLog(
                        childId = childId,
                        type = "KEYWORD_ALERT",
                        title = "ALERT: Dangerous Text Typed!",
                        content = "Suspicious keystrokes logged in $appName: \"$typedText\"",
                        extra = "Severity: High"
                    )
                )
            } else {
                repository.insertLog(
                    ActivityLog(
                        childId = childId,
                        type = "KEYSTROKE",
                        title = appName,
                        content = "Keystroke captured: \"$typedText\"",
                        extra = "Accessibility Hook Active"
                    )
                )
            }
        }
    }

    fun simulateIncomingCall(callerName: String, callerNumber: String, isUnknown: Boolean, durationSeconds: Int) {
        viewModelScope.launch {
            val childId = _selectedChildId.value
            val isShortCall = durationSeconds < 10 && durationSeconds > 0
            val subText = if (isUnknown) "Unknown Contact Alert" else "Registered Contact"

            repository.insertLog(
                ActivityLog(
                    childId = childId,
                    type = "CALL",
                    title = "Incoming: $callerName",
                    content = "Number: $callerNumber | Duration: ${durationSeconds}s | $subText",
                    extra = "Status: Received | Duration: $durationSeconds"
                )
            )

            if (isUnknown) {
                repository.insertLog(
                    ActivityLog(
                        childId = childId,
                        type = "KEYWORD_ALERT",
                        title = "ALERT: Unknown Caller interaction!",
                        content = "Mobile communication detected with unregistered number: $callerNumber ($callerName)",
                        extra = "Severity: Medium"
                    )
                )
            }
            
            if (isShortCall) {
                repository.insertLog(
                    ActivityLog(
                        childId = childId,
                        type = "NOTIFICATION",
                        title = "Suspicious Quick Call",
                        content = "Call from $callerNumber was shorter than 10 seconds (${durationSeconds}s). Potential stealth connection checked.",
                        extra = "Duration: $durationSeconds"
                    )
                )
            }
        }
    }

    fun simulateSmsReceived(senderName: String, senderNumber: String, messageBody: String) {
        viewModelScope.launch {
            val childId = _selectedChildId.value
            val isSuspicious = messageBody.lowercase().contains("meet secretly") || 
                              messageBody.lowercase().contains("suicide") ||
                              messageBody.lowercase().contains("dont tell parents")

            repository.insertLog(
                ActivityLog(
                    childId = childId,
                    type = "SMS",
                    title = "SMS: $senderName",
                    content = "\"$messageBody\"",
                    extra = "Sender: $senderNumber"
                )
            )

            if (isSuspicious) {
                repository.insertLog(
                    ActivityLog(
                        childId = childId,
                        type = "KEYWORD_ALERT",
                        title = "ALERT: Dangerous Context in SMS!",
                        content = "Incoming SMS containing restricted phrase from $senderNumber: \"$messageBody\"",
                        extra = "Severity: High"
                    )
                )
            }
        }
    }

    fun simulateNotificationCaptured(sourceApp: String, messageTitle: String, messageText: String) {
        viewModelScope.launch {
            val childId = _selectedChildId.value
            repository.insertLog(
                ActivityLog(
                    childId = childId,
                    type = "NOTIFICATION",
                    title = "Push: $sourceApp",
                    content = "From $messageTitle: \"$messageText\"",
                    extra = "Pkg: com.$sourceApp.android"
                )
            )
        }
    }

    fun simulateLocationChanged(latitude: Double, longitude: Double) {
        viewModelScope.launch {
            val childId = _selectedChildId.value
            val currentConfig = repository.getConfigDirect(childId)
            
            var isOutside = false
            if (currentConfig != null) {
                // Calculate distance between latitude, longitude and geofenceLat, geofenceLng in meters
                val distance = calculateDistanceInMeters(latitude, longitude, currentConfig.geofenceLat, currentConfig.geofenceLng)
                isOutside = distance > currentConfig.geofenceRadius
            }

            repository.insertLocation(
                ChildLocation(
                    childId = childId,
                    latitude = latitude,
                    longitude = longitude,
                    isOutsideSafeZone = isOutside
                )
            )

            if (isOutside) {
                repository.insertLog(
                    ActivityLog(
                        childId = childId,
                        type = "KEYWORD_ALERT",
                        title = "ALERT: Geofence Breach Deteceted!",
                        content = "Child exited designated safe zone radius. Current location: ($latitude, $longitude)",
                        extra = "Severity: Critical"
                    )
                )
            }
        }
    }

    fun simulateTakeScreenshot(appName: String, mockScreenType: String) {
        viewModelScope.launch {
            val childId = _selectedChildId.value
            repository.insertScreenshot(
                ScreenshotLog(
                    childId = childId,
                    imageData = mockScreenType, // e.g. "MOCK_WHATSAPP", "MOCK_SNAPCHAT", "MOCK_HOMESCREEN"
                    appName = appName
                )
            )
            repository.insertLog(
                ActivityLog(
                    childId = childId,
                    type = "NOTIFICATION",
                    title = "Periodic Screen Capture Saved",
                    content = "Auto screen monitoring snapshot saved for active package: $appName"
                )
            )
        }
    }

    // Basic Haversine formula for simulator geofence math
    private fun calculateDistanceInMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371000.0 // Earth radius in meters
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2)
        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
        return r * c
    }
}

data class ChildProfile(
    val id: String,
    val name: String,
    val battery: String,
    val status: String,
    val currentApp: String
)
