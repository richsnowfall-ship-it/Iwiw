package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import kotlinx.coroutines.launch
import coil.compose.AsyncImage
import coil.request.ImageRequest
import android.content.pm.PackageManager
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.draw.alpha

// Color Theme Palette matched exactly to screenshots
val PrimaryNavy = Color(0xFF0F172A)
val SolidWhite = Color(0xFFFFFFFF)
val SoftBackground = Color(0xFFF8FAFC)
val LightPeach = Color(0xFFFFF2EE)
val TextDark = Color(0xFF1E293B)
val TextMuted = Color(0xFF64748B)

// Feature Colors
val BlockAppsBg = Color(0xFFFCE7F3)
val BlockAppsAccent = Color(0xFFF43F5E)
val AppLimitsBg = Color(0xFFFEF3C7)
val AppLimitsAccent = Color(0xFFD97706)
val GeofencesBg = Color(0xFFE0E7FF)
val GeofencesAccent = Color(0xFF4F46E5)
val ProtectionBg = Color(0xFFD1FAE5)
val ProtectionAccent = Color(0xFF10B981)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MainScreen(viewModel: ParentControlViewModel) {
    var selectedTab by remember { mutableStateOf(0) } // 0: Home, 1: Features, 2: Notifications, 3: Profile/Simulator
    var activeSubScreen by remember { mutableStateOf("main") } // "main" vs "screentime"

    val selectedChildId by viewModel.selectedChildId.collectAsState()
    val activeProfile by viewModel.activeProfile.collectAsState()
    val config by viewModel.config.collectAsState()
    val logs by viewModel.logs.collectAsState()
    val screenshots by viewModel.screenshots.collectAsState()
    val locations by viewModel.locations.collectAsState()

    val coroutineScope = rememberCoroutineScope()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(SoftBackground)
    ) {
        if (activeSubScreen == "screentime") {
            // Detailed Screen Time View (Screenshot 3)
            DetailedScreenTimeView(
                viewModel = viewModel,
                config = config ?: DeviceConfig(childId = selectedChildId),
                onBack = { activeSubScreen = "main" }
            )
        } else {
            // Main Bottom Bar Navigation Shell
            Column(modifier = Modifier.fillMaxSize()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    when (selectedTab) {
                        0 -> HomeDashboardTab(
                            viewModel = viewModel,
                            activeProfile = activeProfile,
                            logs = logs,
                            locations = locations,
                            config = config ?: DeviceConfig(childId = selectedChildId)
                        )
                        1 -> FeaturesTab(
                            viewModel = viewModel,
                            activeProfile = activeProfile,
                            config = config ?: DeviceConfig(childId = selectedChildId),
                            onNavigateToScreenTime = { activeSubScreen = "screentime" }
                        )
                        2 -> NotificationsListTab(
                            viewModel = viewModel,
                            logs = logs
                        )
                        3 -> SimulatorControlTab(
                            viewModel = viewModel,
                            selectedChildId = selectedChildId,
                            config = config ?: DeviceConfig(childId = selectedChildId),
                            logs = logs,
                            screenshots = screenshots,
                            activeProfile = activeProfile
                        )
                    }
                }

                // Premium Custom Floating BottNav matching screenshots
                CustomBottomNavigationBar(
                    selectedTab = selectedTab,
                    onTabSelected = { selectedTab = it }
                )
            }
        }
    }
}

// ==========================================
// CUSTOM VECTOR MAP COMPOSABLE (SCREENSHOT 1)
// ==========================================
@Composable
fun CityMapCanvas(
    modifier: Modifier = Modifier,
    locations: List<ChildLocation>
) {
    val activeLoc = locations.firstOrNull() ?: ChildLocation(childId = "Emily-01", latitude = 28.6139, longitude = 77.2090)

    Box(modifier = modifier) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Background land (light styled grey-beige maps color)
            drawRect(color = Color(0xFFF1F5F9))

            // Draw Parks / Woodlands
            val parkPath1 = Path().apply {
                moveTo(w * 0.05f, h * 0.25f)
                lineTo(w * 0.22f, h * 0.21f)
                lineTo(w * 0.25f, h * 0.35f)
                lineTo(w * 0.08f, h * 0.38f)
                close()
            }
            drawPath(path = parkPath1, color = Color(0xFFE2F1E4))

            val parkPath2 = Path().apply {
                moveTo(w * 0.15f, h * 0.70f)
                lineTo(w * 0.35f, h * 0.65f)
                lineTo(w * 0.38f, h * 0.85f)
                lineTo(w * 0.18f, h * 0.88f)
                close()
            }
            drawPath(path = parkPath2, color = Color(0xFFE2F1E4))

            // Draw Streets/Roads lines
            val roadColor = Color(0xFFFFFFFF)
            val streetOutlineColor = Color(0xFFE2E8F0)

            // Pulawska Street (Vertical diagonal main road)
            drawLine(
                color = streetOutlineColor,
                start = Offset(w * 0.52f, 0f),
                end = Offset(w * 0.48f, h),
                strokeWidth = 32.dp.toPx()
            )
            drawLine(
                color = roadColor,
                start = Offset(w * 0.52f, 0f),
                end = Offset(w * 0.48f, h),
                strokeWidth = 28.dp.toPx()
            )

            // Alaja Wilanowska Street (Horizontal diagonal main road)
            drawLine(
                color = streetOutlineColor,
                start = Offset(0f, h * 0.30f),
                end = Offset(w, h * 0.40f),
                strokeWidth = 26.dp.toPx()
            )
            drawLine(
                color = roadColor,
                start = Offset(0f, h * 0.30f),
                end = Offset(w, h * 0.40f),
                strokeWidth = 22.dp.toPx()
            )

            // Warniedsskia Street
            drawLine(
                color = roadColor,
                start = Offset(w * 0.40f, h * 0.35f),
                end = Offset(w * 0.85f, h * 0.68f),
                strokeWidth = 14.dp.toPx()
            )

            // Begwewska Street
            drawLine(
                color = roadColor,
                start = Offset(w * 0.75f, 0f),
                end = Offset(w * 0.70f, h * 0.58f),
                strokeWidth = 14.dp.toPx()
            )

            // Stensza Street
            drawLine(
                color = roadColor,
                start = Offset(w * 0.30f, h * 0.55f),
                end = Offset(w * 0.45f, h * 0.95f),
                strokeWidth = 10.dp.toPx()
            )

            // Romu Street
            drawLine(
                color = roadColor,
                start = Offset(w * 0.65f, h * 0.45f),
                end = Offset(w * 0.88f, h * 0.80f),
                strokeWidth = 12.dp.toPx()
            )

            // Draw river stream or train lines (Wilanowska S-Bahn track representation)
            val trackColor = Color(0xFFCBD5E1)
            drawLine(
                color = trackColor,
                start = Offset(w * 0.12f, 0f),
                end = Offset(w * 0.12f, h),
                strokeWidth = 3.dp.toPx(),
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 15f), 0f)
            )
        }

        // Street Label Text Overlays
        Text(
            text = "Alaja Wilanowska",
            color = TextMuted,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.TopStart).padding(start = 60.dp, top = hToDp(0.24f))
        )
        Text(
            text = "Pulawska",
            color = TextMuted,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.TopCenter).padding(start = 24.dp, top = hToDp(0.45f))
        )
        Text(
            text = "Warniedsskia",
            color = TextMuted,
            fontSize = 8.sp,
            modifier = Modifier.align(Alignment.CenterEnd).padding(end = 64.dp, top = 8.dp)
        )
        Text(
            text = "Begwewska",
            color = TextMuted,
            fontSize = 8.sp,
            modifier = Modifier.align(Alignment.TopEnd).padding(end = 50.dp, top = 40.dp)
        )

        // Wilanowska Metro sign representation
        Row(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = hToDp(0.12f), start = 45.dp)
                .background(Color(0xFF0284C7), RoundedCornerShape(2.dp))
                .padding(horizontal = 4.dp, vertical = 1.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Wilanewska", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.width(2.dp))
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .background(Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("M", color = Color(0xFF0284C7), fontSize = 7.sp, fontWeight = FontWeight.Black)
            }
        }

        // Active Child Drop Target Marker (Emily's face with drop pin background)
        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .offset(y = (-20).dp)
        ) {
            // Pulsing target circle
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .background(Color(0x224F46E5), CircleShape)
                    .border(1.dp, Color(0x444F46E5), CircleShape)
                    .align(Alignment.Center)
            )

            // Inner circle pin with cute avatar drawing
            Card(
                shape = CircleShape,
                border = BorderStroke(3.dp, Color(0xFF4F46E5)),
                modifier = Modifier
                    .size(34.dp)
                    .align(Alignment.Center)
                    .shadow(4.dp, CircleShape)
            ) {
                AvatarVectorEmily(modifier = Modifier.fillMaxSize())
            }
            
            // Pointer tail
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .align(Alignment.BottomCenter)
                    .offset(y = 16.dp)
                    .background(Color(0xFF4F46E5), CircleShape)
            )
        }
    }
}

fun hToDp(fraction: Float): androidx.compose.ui.unit.Dp {
    return (fraction * 450).dp
}

// ==========================================
// CUTE EMILY VECTOR AVATAR DRAWING
// ==========================================
@Composable
fun AvatarVectorEmily(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // Background Circle color (Peach/Pink background)
        drawCircle(color = Color(0xFFFED7AA))

        // Hair back
        drawCircle(color = Color(0xFF312E81), radius = w * 0.42f, center = Offset(w / 2, h * 0.45f))

        // Face Circle
        drawCircle(color = Color(0xFFFFE4E6), radius = w * 0.32f, center = Offset(w / 2, h * 0.52f))

        // Cute eyes
        drawCircle(color = Color(0xFF1E293B), radius = w * 0.04f, center = Offset(w * 0.4f, h * 0.5f))
        drawCircle(color = Color(0xFF1E293B), radius = w * 0.04f, center = Offset(w * 0.6f, h * 0.5f))

        // Smile
        drawArc(
            color = Color(0xFFE11D48),
            startAngle = 0f,
            sweepAngle = 180f,
            useCenter = false,
            topLeft = Offset(w * 0.44f, h * 0.54f),
            size = Size(w * 0.12f, h * 0.08f),
            style = Stroke(width = 2.dp.toPx())
        )

        // Hair front / fringe curves
        val hairPath = Path().apply {
            moveTo(w * 0.15f, h * 0.35f)
            quadraticTo(w * 0.35f, h * 0.28f, w * 0.5f, h * 0.38f)
            quadraticTo(w * 0.65f, h * 0.28f, w * 0.85f, h * 0.35f)
            lineTo(w * 0.85f, h * 0.20f)
            lineTo(w * 0.15f, h * 0.20f)
            close()
        }
        drawPath(path = hairPath, color = Color(0xFF312E81))

        // Side hair tails
        drawRoundRect(
            color = Color(0xFF312E81),
            topLeft = Offset(w * 0.12f, h * 0.38f),
            size = Size(w * 0.1f, h * 0.35f),
            cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
        )
        drawRoundRect(
            color = Color(0xFF312E81),
            topLeft = Offset(w * 0.78f, h * 0.38f),
            size = Size(w * 0.1f, h * 0.35f),
            cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
        )
    }
}

// ==========================================
// COMPONENT: FLOATING HEADER CARD (S1 & S2)
// ==========================================
@Composable
fun FloatingChildHeaderCard(
    activeProfile: ChildProfile,
    viewModel: ParentControlViewModel,
    modifier: Modifier = Modifier
) {
    var showChildMenu by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = SolidWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .clickable { showChildMenu = true }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Child Avatar Picture Circle
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFECEFF1))
            ) {
                AvatarVectorEmily(modifier = Modifier.fillMaxSize())
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Info (Title, status, battery)
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = activeProfile.name,
                    color = TextDark,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Status green dot
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .background(Color(0xFF22C55E), CircleShape)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = activeProfile.status,
                        color = Color(0xFF10B981),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    
                    // Battery indicator
                    Icon(
                        imageVector = Icons.Default.Refresh, // Placeholder for battery, or custom line icon
                        contentDescription = "Battery",
                        tint = TextMuted,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = activeProfile.battery,
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                }
            }

            // Expand Chevron down arrow
            Icon(
                imageVector = Icons.Default.KeyboardArrowDown,
                contentDescription = "Select child",
                tint = TextMuted,
                modifier = Modifier.size(24.dp)
            )

            // Child profile dropdown list selector
            DropdownMenu(
                expanded = showChildMenu,
                onDismissRequest = { showChildMenu = false },
                modifier = Modifier
                    .background(SolidWhite)
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(8.dp))
            ) {
                viewModel.childrenProfiles.forEach { profile ->
                    DropdownMenuItem(
                        text = {
                            Text(
                                text = profile.name,
                                color = if (profile.id == activeProfile.id) Color(0xFF4F46E5) else TextDark,
                                fontWeight = if (profile.id == activeProfile.id) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        onClick = {
                            viewModel.selectChild(profile.id)
                            showChildMenu = false
                        }
                    )
                }
            }
        }
    }
}

// ==========================================
// TAB 0: HOME SCREEN (SCREENSHOT 1)
// ==========================================
@Composable
fun HomeDashboardTab(
    viewModel: ParentControlViewModel,
    activeProfile: ChildProfile,
    logs: List<ActivityLog>,
    locations: List<ChildLocation>,
    config: DeviceConfig
) {
    Box(modifier = Modifier.fillMaxSize()) {
        // Map as background
        CityMapCanvas(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.65f),
            locations = locations
        )

        // Top Floating profile selection header card
        FloatingChildHeaderCard(
            activeProfile = activeProfile,
            viewModel = viewModel,
            modifier = Modifier.align(Alignment.TopCenter)
        )

        // Floating Location Summary Card (School, 5 min ago)
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = SolidWhite),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 180.dp, start = 16.dp, end = 16.dp)
                .fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Pin location icon with pink background
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .background(Color(0xFFFEE2E2), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = Color(0xFFEF4444),
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "School",
                        color = TextDark,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Current location - 5 min ago",
                        color = TextMuted,
                        fontSize = 13.sp
                    )
                }

                // Vertical separator
                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .height(36.dp)
                        .background(Color(0xFFE2E8F0))
                )

                Spacer(modifier = Modifier.width(14.dp))

                // GPS direction arrow icon + word "Location"
                Column(
                    modifier = Modifier.clickable { },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow, // Rotate or draw visual triangle arrow
                        contentDescription = "Location navigation",
                        tint = Color(0xFF312E81),
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = "Location",
                        color = Color(0xFF312E81),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Recent Activity Sliding bottom sheet (Takes lower half)
        Card(
            shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
            colors = CardDefaults.cardColors(containerColor = SolidWhite),
            elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.55f)
                .align(Alignment.BottomCenter)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp, vertical = 20.dp)
            ) {
                // Section Title Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Recent Activity",
                        color = TextDark,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "All activity",
                        color = Color(0xFF4F46E5),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Timeline list
                val appActivityLogs = logs.filter { it.type == "APP_USAGE" }
                if (appActivityLogs.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No recorded app activities yet.",
                            color = TextMuted,
                            fontSize = 14.sp
                        )
                    }
                } else {
                    Box(modifier = Modifier.weight(1f)) {
                        // Drawing timeline line background on left
                        Canvas(
                            modifier = Modifier
                                .fillMaxHeight()
                                .width(20.dp)
                                .offset(x = 6.dp)
                        ) {
                            drawLine(
                                color = Color(0xFFFCA5A5),
                                start = Offset(size.width / 2, 0f),
                                end = Offset(size.width / 2, size.height),
                                strokeWidth = 1.5.dp.toPx()
                            )
                        }

                        // Scrollable list items
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(appActivityLogs) { log ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Bullet node
                                    Box(
                                        modifier = Modifier
                                            .size(14.dp)
                                            .border(2.5.dp, Color(0xFFEF4444), CircleShape)
                                            .background(SolidWhite, CircleShape)
                                    )

                                    Spacer(modifier = Modifier.width(14.dp))

                                    // Activity colored card
                                    Card(
                                        shape = RoundedCornerShape(16.dp),
                                        colors = CardDefaults.cardColors(containerColor = LightPeach),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable { }
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 14.dp, vertical = 12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            // App Icon container — real icon fills properly
                                            AppLogoComponent(
                                                packageNameOrAppName = log.title,
                                                size = 44.dp
                                            )

                                            Spacer(modifier = Modifier.width(12.dp))

                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = log.title,
                                                    color = TextDark,
                                                    fontSize = 15.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Text(
                                                    text = log.content, // duration text e.g., "3 Minutes"
                                                    color = TextMuted,
                                                    fontSize = 13.sp
                                                )
                                            }

                                            // Time label & Chevron Right
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = log.extra, // e.g. "5 min ago" or "08:21 AM"
                                                    color = TextMuted,
                                                    fontSize = 12.sp
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Icon(
                                                    imageVector = Icons.Default.KeyboardArrowDown, // Rotate sideways later or keep clean arrow
                                                    contentDescription = null,
                                                    tint = TextMuted,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// REAL APP ICON LOADER — Coil + PackageManager
// ==========================================

/**
 * AppLogoComponent — Ab real app icons dikhata hai device se.
 *
 * @param packageNameOrAppName — App ka package name (com.google.android.youtube)
 *                               ya display name (YouTube, Instagram, WhatsApp)
 * @param size — Icon ka size
 *
 * Kaise kaam karta hai:
 * 1. Pehle PackageManager se real installed app ka icon load karta hai
 * 2. Agar app installed nahi hai to fallback colored placeholder dikhata hai
 * 3. Icon RoundedCornerShape mein clip hota hai — smooth aur professional lagta hai
 */
@Composable
fun AppLogoComponent(packageNameOrAppName: String, size: androidx.compose.ui.unit.Dp) {
    val context = LocalContext.current

    val resolvedPackage = remember(packageNameOrAppName) {
        resolvePackageName(packageNameOrAppName)
    }

    val fallbackColor = remember(packageNameOrAppName) {
        generateColorFromName(packageNameOrAppName)
    }

    val isInstalled = remember(resolvedPackage) {
        resolvedPackage != null && isPackageInstalled(context, resolvedPackage)
    }

    // Smooth fade-in state
    var isLoaded by remember { mutableStateOf(false) }
    val alpha by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (isLoaded) 1f else 0f,
        animationSpec = androidx.compose.animation.core.tween(durationMillis = 250),
        label = "iconFade"
    )

    Box(
        modifier = Modifier
            .size(size)
            .shadow(
                elevation = 3.dp,
                shape = RoundedCornerShape(size * 0.22f),
                ambientColor = Color.Black.copy(alpha = 0.12f),
                spotColor = Color.Black.copy(alpha = 0.08f)
            )
            .clip(RoundedCornerShape(size * 0.22f)),
        contentAlignment = Alignment.Center
    ) {
        if (isInstalled) {
            // Real installed app icon
            AsyncImage(
                model = ImageRequest.Builder(context)
                    .data(AppIconFetcher(context, resolvedPackage))
                    .crossfade(200)
                    .build(),
                contentDescription = packageNameOrAppName,
                modifier = Modifier
                    .fillMaxSize()
                    .alpha(alpha),
                onSuccess = { isLoaded = true },
                onError = { isLoaded = true }
            )
        } else {
            // Fallback — colored background + initial letter
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.linearGradient(
                            listOf(
                                fallbackColor,
                                fallbackColor.copy(alpha = 0.75f)
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = packageNameOrAppName.take(1).uppercase(),
                    color = Color.White,
                    fontSize = (size.value * 0.42f).sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 0.sp
                )
            }
            LaunchedEffect(Unit) { isLoaded = true }
        }
    }
}

/**
 * App display name se package name resolve karo
 */
fun resolvePackageName(nameOrPackage: String): String? {
    // Already a package name
    if (nameOrPackage.contains(".")) return nameOrPackage

    return when (nameOrPackage.lowercase().trim()) {
        "youtube"              -> "com.google.android.youtube"
        "instagram"            -> "com.instagram.android"
        "whatsapp", "whats app" -> "com.whatsapp"
        "tiktok", "tik tok"   -> "com.zhiliaoapp.musically"
        "facebook"             -> "com.facebook.katana"
        "snapchat"             -> "com.snapchat.android"
        "twitter", "x"        -> "com.twitter.android"
        "telegram"             -> "org.telegram.messenger"
        "chrome"               -> "com.android.chrome"
        "gmail"                -> "com.google.android.gm"
        "maps", "google maps" -> "com.google.android.apps.maps"
        "spotify"              -> "com.spotify.music"
        "netflix"              -> "com.netflix.mediaclient"
        "pubg"                 -> "com.tencent.ig"
        "freefire", "free fire" -> "com.dts.freefireth"
        "minecraft"            -> "com.mojang.minecraftpe"
        "calculator"           -> "com.google.android.calculator"
        "camera"               -> "com.android.camera2"
        "settings"             -> "com.android.settings"
        "phone", "dialer"      -> "com.android.dialer"
        "messages", "sms"      -> "com.google.android.apps.messaging"
        "photos"               -> "com.google.android.apps.photos"
        "play store"           -> "com.android.vending"
        else -> null
    }
}

/**
 * Check karo ki package device pe installed hai ya nahi
 */
fun isPackageInstalled(context: android.content.Context, packageName: String): Boolean {
    return try {
        context.packageManager.getPackageInfo(packageName, 0)
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }
}

/**
 * App naam se consistent color generate karo
 * Isse same app ko hamesha same color milega — random nahi lagega
 */
fun generateColorFromName(name: String): Color {
    val colors = listOf(
        Color(0xFF6366F1), // Indigo
        Color(0xFFEC4899), // Pink
        Color(0xFF14B8A6), // Teal
        Color(0xFFF59E0B), // Amber
        Color(0xFF8B5CF6), // Purple
        Color(0xFF06B6D4), // Cyan
        Color(0xFF10B981), // Emerald
        Color(0xFFEF4444), // Red
        Color(0xFF3B82F6), // Blue
        Color(0xFFF97316), // Orange
    )
    val index = name.hashCode().and(0x7FFFFFFF) % colors.size
    return colors[index]
}

/**
 * Coil ke liye custom data class — package name se icon fetch karta hai
 */
data class AppIconFetcher(
    val context: android.content.Context,
    val packageName: String?
)

// ==========================================
// TAB 1: FEATURES LIST SCREEN (SCREENSHOT 2)
// ==========================================
@Composable
fun FeaturesTab(
    viewModel: ParentControlViewModel,
    activeProfile: ChildProfile,
    config: DeviceConfig,
    onNavigateToScreenTime: () -> Unit
) {
    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Navy Header representing today limit with overlays
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.35f)
                    .background(Color(0xFF1E3A8A)) // Deep blue gradient
            ) {
                // Background artistic intersecting solid pink circles
                Canvas(modifier = Modifier.fillMaxSize()) {
                    // Left upper circle
                    drawCircle(
                        color = Color(0xFFEC4899).copy(alpha = 0.5f),
                        radius = size.width * 0.25f,
                        center = Offset(-50f, 100f)
                    )
                    // Right bottom circle
                    drawCircle(
                        color = Color(0xFFD946EF).copy(alpha = 0.35f),
                        radius = size.width * 0.16f,
                        center = Offset(size.width - 40f, size.height * 0.7f)
                    )
                    // Additional decorative bubble
                    drawCircle(
                        color = Color(0xFFEC4899).copy(alpha = 0.3f),
                        radius = size.width * 0.10f,
                        center = Offset(size.width * 0.72f, size.height * 0.22f)
                    )
                }

                // Header Contents
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 24.dp, vertical = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Spacer(modifier = Modifier.height(44.dp))
                    Text(
                        text = "1 hrs 25 min",
                        color = Color.White,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = (-0.5).sp,
                        modifier = Modifier.clickable { onNavigateToScreenTime() }
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Today's time limit",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Bottom feature sheets grid on off-white background
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(Color(0xFFF1F5F9))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 50.dp)
                ) {
                    // 2x2 Grid of Feature items
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Card 1
                        FeatureItemCard(
                            bgTint = BlockAppsBg,
                            accentColor = BlockAppsAccent,
                            icon = Icons.Default.Warning,
                            title = "Block Apps &\nSites",
                            countLabel = "4 Apps\n2421 Websites",
                            modifier = Modifier.weight(1f),
                            onClick = onNavigateToScreenTime
                        )
                        // Card 2
                        FeatureItemCard(
                            bgTint = AppLimitsBg,
                            accentColor = AppLimitsAccent,
                            icon = Icons.Default.Menu, // Represent grid
                            title = "App Limits",
                            countLabel = "12 Apps",
                            modifier = Modifier.weight(1f),
                            onClick = onNavigateToScreenTime
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Card 3
                        FeatureItemCard(
                            bgTint = GeofencesBg,
                            accentColor = GeofencesAccent,
                            icon = Icons.Default.LocationOn,
                            title = "Geofences",
                            countLabel = "8 Locations saved",
                            modifier = Modifier.weight(1f),
                            onClick = { }
                        )
                        // Card 4
                        FeatureItemCard(
                            bgTint = ProtectionBg,
                            accentColor = ProtectionAccent,
                            icon = Icons.Default.CheckCircle,
                            title = "Device\nProtection",
                            countLabel = "1 Restrictions",
                            modifier = Modifier.weight(1f),
                            onClick = { }
                        )
                    }
                }
            }
        }

        // Floating quick actions bar floating above the blue header bottom line
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = SolidWhite),
            elevation = CardDefaults.cardElevation(defaultElevation = 5.dp),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 188.dp, start = 20.dp, end = 20.dp)
                .fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Action 1: Lock Phone
                QuickCommandColumn(
                    icon = Icons.Default.Lock,
                    label = "Lock phone",
                    isActive = config.isPhoneLocked,
                    onClick = { viewModel.setPhoneLocked(!config.isPhoneLocked) },
                    modifier = Modifier.weight(1f)
                )

                VerticalBarDivider()

                // Action 2: Pause
                QuickCommandColumn(
                    icon = Icons.Default.Warning, // Two vertical bars or pause placeholder
                    label = "Pause",
                    isActive = false,
                    onClick = { },
                    modifier = Modifier.weight(1f)
                )

                VerticalBarDivider()

                // Action 3: Add Time
                QuickCommandColumn(
                    icon = Icons.Default.Add,
                    label = "Add time",
                    isActive = false,
                    onClick = { },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Profile card floating layout on top
        FloatingChildHeaderCard(
            activeProfile = activeProfile,
            viewModel = viewModel,
            modifier = Modifier.align(Alignment.TopCenter)
        )
    }
}

@Composable
fun VerticalBarDivider() {
    Box(
        modifier = Modifier
            .width(1.dp)
            .height(28.dp)
            .background(Color(0xFFE2E8F0))
    )
}

@Composable
fun QuickCommandColumn(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    isActive: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.clickable { onClick() },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (isActive) Color(0xFFFF4D5E) else Color(0xFF1E3A8A),
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            color = Color(0xFF1E3A8A),
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

// 2x2 Feature card component
@Composable
fun FeatureItemCard(
    bgTint: Color,
    accentColor: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    countLabel: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = bgTint),
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(18.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // White circular icon background
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .background(SolidWhite, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Column {
                Text(
                    text = title,
                    color = TextDark,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 22.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = countLabel,
                    color = accentColor,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    lineHeight = 16.sp
                )
            }
        }
    }
}

// ==========================================
// SCREEN 3: DETAILED SCREEN TIME (SCREENSHOT 3)
// ==========================================
@Composable
fun DetailedScreenTimeView(
    viewModel: ParentControlViewModel,
    config: DeviceConfig,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SoftBackground)
    ) {
        // Simple Top Navigation Chevron Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .background(Color.White)
                .statusBarsPadding(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = TextDark
                )
            }
            Spacer(modifier = Modifier.width(70.dp))
            Text(
                text = "Screen Time",
                color = TextDark,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Center Header Details
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "1 hrs 15 min /day",
                        color = TextDark,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black
                    )

                    // Dropdown "Today" card
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F5F9)),
                        modifier = Modifier.wrapContentSize()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Today", color = TextDark, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(Icons.Default.KeyboardArrowDown, null, tint = TextDark, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }

            // Stacked Bar Graph drawing region
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SolidWhite),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Canvas(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp)
                        ) {
                            val w = size.width
                            val h = size.height
                            
                            // Y-gridlines (0m, 20m, 40m, 60m levels)
                            val gridLineColor = Color(0xFFE2E8F0)
                            val levels = listOf(0.1f, 0.4f, 0.7f, 1.0f)
                            levels.forEach { fraction ->
                                drawLine(
                                    color = gridLineColor,
                                    start = Offset(0f, h * fraction),
                                    end = Offset(w, h * fraction),
                                    strokeWidth = 1f
                                )
                            }

                            // Dotted horizontal daily threshold line
                            val thresholdY = h * 0.52f
                            drawLine(
                                color = Color(0xFFFF4D5E),
                                start = Offset(0f, thresholdY),
                                end = Offset(w, thresholdY),
                                strokeWidth = 1.5.dp.toPx(),
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                            )

                            // Render Stacked Bar charts
                            // Categorised widths: Blue (Communication), Pink (Entertainment), Black (Games)
                            val barWidth = 24.dp.toPx()
                            val barPositions = listOf(0.18f, 0.36f, 0.55f, 0.73f, 0.90f)
                            val barHeights = listOf(
                                Triple(0.2f, 0.05f, 0.02f), // Communication, Entertainment, Games
                                Triple(0.1f, 0.15f, 0.05f),
                                Triple(0.4f, 0.2f, 0.08f),
                                Triple(0.35f, 0.15f, 0.1f),
                                Triple(0.15f, 0.05f, 0.02f)
                            )

                            barPositions.forEachIndexed { idx, xPos ->
                                val pxX = w * xPos
                                val hValues = barHeights[idx]

                                var currentBaseY = h
                                
                                // Comm bar (Blue color)
                                val commHeight = h * hValues.first
                                drawRect(
                                    color = Color(0xFF1E3A8A),
                                    topLeft = Offset(pxX - barWidth/2, currentBaseY - commHeight),
                                    size = Size(barWidth, commHeight)
                                )
                                currentBaseY -= commHeight

                                // Ent bar (Pink color)
                                val entHeight = h * hValues.second
                                drawRect(
                                    color = Color(0xFFEC4899),
                                    topLeft = Offset(pxX - barWidth/2, currentBaseY - entHeight),
                                    size = Size(barWidth, entHeight)
                                )
                                currentBaseY -= entHeight

                                // Games bar (Black color)
                                val gamesHeight = h * hValues.third
                                drawRect(
                                    color = Color(0xFF1E293B),
                                    topLeft = Offset(pxX - barWidth/2, currentBaseY - gamesHeight),
                                    size = Size(barWidth, gamesHeight)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // X Axis values
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("6am", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("8am", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("12pm", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("6pm", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Legends region layout matching ScreenshotY
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            LegendBulletItem(color = Color(0xFF1E3A8A), title = "Communication", value = "52m 3s")
                            LegendBulletItem(color = Color(0xFFEC4899), title = "Entertainment", value = "24m 42s")
                            LegendBulletItem(color = Color(0xFF1E293B), title = "Games", value = "8m 21s")
                        }
                    }
                }
            }

            // App Usage & Blocker lists with switch toggles
            item {
                Text(
                    text = "App Usage & Blocker",
                    color = TextDark,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            // Row items lists
            val appUsageData = listOf(
                AppUsageLimitData("Instagram", "20m 1s", true),
                AppUsageLimitData("Whatsapp", "21m 32s", true),
                AppUsageLimitData("Youtube", "10m 12s", false)
            )

            items(appUsageData) { item ->
                AppUsageBlockRow(item = item)
            }
        }
    }
}

@Composable
fun LegendBulletItem(color: Color, title: String, value: String) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(color, CircleShape)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(title, color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(value, color = TextDark, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 12.dp))
    }
}

data class AppUsageLimitData(
    val name: String,
    val durationText: String,
    val isAllowed: Boolean
)

@Composable
fun AppUsageBlockRow(item: AppUsageLimitData) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SolidWhite),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // App Icon — real icon, proper size
            AppLogoComponent(
                packageNameOrAppName = item.name,
                size = 48.dp
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.name,
                    color = TextDark,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Set Time Limit >",
                    color = Color(0xFF6366F1),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable { }
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = item.durationText,
                    color = TextMuted,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.width(10.dp))
                
                // Switch tracker toggle
                var isChecked by remember { mutableStateOf(item.isAllowed) }
                Switch(
                    checked = isChecked,
                    onCheckedChange = { isChecked = it },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = SolidWhite,
                        checkedTrackColor = Color(0xFF4F46E5),
                        uncheckedThumbColor = Color(0xFF94A3B8),
                        uncheckedTrackColor = Color(0xFFE2E8F0)
                    )
                )
            }
        }
    }
}

// ==========================================
// TAB 2: SECURE SYSTEM NOTIFICATIONS / ALERTS LISTS
// ==========================================
@Composable
fun NotificationsListTab(
    viewModel: ParentControlViewModel,
    logs: List<ActivityLog>
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Child Security Alerts",
                color = TextDark,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Clear All",
                color = BlockAppsAccent,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { viewModel.clearAllLogs() }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        val securityAlerts = logs.filter { it.type == "KEYWORD_ALERT" || it.type == "NOTIFICATION" }
        if (securityAlerts.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = ProtectionAccent,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Emily's phone is fully secured.",
                        color = TextMuted,
                        fontSize = 14.sp
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f).fillMaxWidth()
            ) {
                items(securityAlerts) { alert ->
                    // Reddish alert notification card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF1F2)),
                        border = BorderStroke(1.dp, Color(0xFFFECDD3)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = Color(0xFFE11D48),
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = alert.title,
                                    color = TextDark,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(alert.content, color = TextDark, fontSize = 13.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = java.text.SimpleDateFormat("hh:mm a | dd MMM", java.util.Locale.getDefault()).format(java.util.Date(alert.timestamp)),
                                    color = TextMuted,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// TAB 3: SIMULATOR WORKSTATION (PROFILE SCREEN)
// ==========================================
@Composable
fun SimulatorControlTab(
    viewModel: ParentControlViewModel,
    selectedChildId: String,
    config: DeviceConfig,
    logs: List<ActivityLog>,
    screenshots: List<ScreenshotLog>,
    activeProfile: ChildProfile
) {
    var keystrokeInput by remember { mutableStateOf("") }
    var mockSmsInput by remember { mutableStateOf("Hey Aarav, let's meet secretly, but dont tell parents.") }
    var mockCallNameInput by remember { mutableStateOf("Stranger Admin") }
    var mockCallNumberInput by remember { mutableStateOf("+91-888-999-011") }
    var locationProgress by remember { mutableStateOf(0.4f) }

    val simLat = config.geofenceLat + (locationProgress - 0.4f) * 0.015
    val simLng = config.geofenceLng + (locationProgress - 0.4f) * 0.015

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F5F9))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "CHILD AGENT SIMULATION WORKSTATION",
                        color = Color(0xFF1E3A8A),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Test the reactivity of your Secure Console! Trigger events like typing toxic text, SMS delivery, or GPS coordinate shift bounds and verify real updates.",
                        color = TextDark,
                        fontSize = 13.sp
                    )
                }
            }
        }

        // Simulating the keylogger typing alerts
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SolidWhite),
                border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("1. Simulate Keyboard Activity (Typing Alerts)", color = TextDark, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = keystrokeInput,
                        onValueChange = { keystrokeInput = it },
                        placeholder = { Text("Type keys here...") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF4F46E5),
                            unfocusedBorderColor = Color(0xFFCBD5E1)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                if (keystrokeInput.isNotEmpty()) {
                                    viewModel.simulateKeystroke("WhatsApp", keystrokeInput)
                                    keystrokeInput = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4F46E5))
                        ) {
                            Text("Log Typing Text", color = Color.White)
                        }

                        // Hot Trigger Trigger alert keyword
                        Text(
                            text = "Assert Panic Alarm Trigger",
                            fontSize = 12.sp,
                            color = BlockAppsAccent,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .border(1.dp, BlockAppsAccent, RoundedCornerShape(12.dp))
                                .clickable {
                                    viewModel.simulateKeystroke("Instagram", "I cannot cope, I am thinking of suicide...")
                                }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        // SMS Message intercepts
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SolidWhite),
                border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("2. Sim SMS message intercept payload", color = TextDark, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = mockSmsInput,
                        onValueChange = { mockSmsInput = it },
                        placeholder = { Text("SMS body contents...") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF4F46E5),
                            unfocusedBorderColor = Color(0xFFCBD5E1)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            viewModel.simulateSmsReceived("Preet Direct", "+91-999-555-081", mockSmsInput)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4F46E5))
                    ) {
                        Text("Simulate SMS Interception", color = Color.White)
                    }
                }
            }
        }

        // Live location simulation slider
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SolidWhite),
                border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("3. Sim Coordinate Perimeter GPS breaches", color = TextDark, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Simulate Geofence Range status", color = TextMuted, fontSize = 12.sp)
                        Text(
                            text = if (locationProgress > 0.6f) "OUTSIDE GEOFENCE SAFE LIMITS" else "INSIDE DESIGNATED GEOFENCE SAFE ZONE",
                            color = if (locationProgress > 0.6f) Color(0xFFE11D48) else Color(0xFF10B981),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Slider(
                        value = locationProgress,
                        onValueChange = {
                            locationProgress = it
                            viewModel.simulateLocationChanged(simLat, simLng)
                        },
                        valueRange = 0.1f..1.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF4F46E5),
                            activeTrackColor = Color(0xFF4F46E5)
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Lat: ${String.format("%.5f", simLat)}", color = TextMuted, fontSize = 11.sp)
                        Text("Lng: ${String.format("%.5f", simLng)}", color = TextMuted, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

// ==========================================
// COMPONENT: PREMIUM FLOATING BOTTOMNAVBAR
// ==========================================
@Composable
fun CustomBottomNavigationBar(
    selectedTab: Int,
    onTabSelected: (Int) -> Unit
) {
    Card(
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = SolidWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, bottom = 12.dp)
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp, horizontal = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val tabs = listOf("Home", "Features", "Notifications", "Profile")
            val icons = listOf(Icons.Default.Home, Icons.Default.Menu, Icons.Default.Notifications, Icons.Default.Person)

            tabs.forEachIndexed { idx, title ->
                val isSelected = selectedTab == idx
                val tintColor = if (isSelected) Color(0xFF1E3A8A) else TextMuted

                Column(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (isSelected) Color(0xFFF1F5F9) else Color.Transparent)
                        .clickable { onTabSelected(idx) }
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = icons[idx],
                        contentDescription = title,
                        tint = tintColor,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = title,
                        color = tintColor,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }
    }
}
