package com.example.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.data.ActivityLog
import com.example.data.AppDatabase
import com.example.data.ParentControlRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * ShieldGuardAccessibilityService
 *
 * Yah service child ke phone mein silently background mein chalti hai.
 * Iske teen kaam hain:
 *  1. Screen pe jo bhi text/content display ho — woh capture karna
 *  2. Kaunsa app open hai — track karna
 *  3. Dangerous keywords detect hone par alert log karna
 */
class ShieldGuardAccessibilityService : AccessibilityService() {

    // Coroutine scope for background DB operations
    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.IO + serviceJob)

    private lateinit var repository: ParentControlRepository

    // Currently active app package
    private var currentPackage: String = ""
    private var lastLoggedPackage: String = ""

    // Dangerous keywords jo detect karni hain
    private val dangerousKeywords = listOf(
        "suicide", "kill myself", "hate myself", "want to die",
        "end my life", "meet secretly", "dont tell parents",
        "run away", "beat me", "hurting me", "send me photos",
        "come alone", "our secret", "marna chahta", "marna chahti",
        "jeena nahi", "mar jaunga", "mar jaungi", "khatam kar lun"
    )

    // Child ID — production mein yah shared prefs se aayega
    private val childId = "child_001"

    override fun onServiceConnected() {
        super.onServiceConnected()

        // Initialize repository
        val database = AppDatabase.getDatabase(this)
        repository = ParentControlRepository(database)

        // Service configuration
        val info = AccessibilityServiceInfo().apply {
            // In events ko monitor karo
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                    AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                    AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED or
                    AccessibilityEvent.TYPE_ANNOUNCEMENT

            // Saare apps monitor karo
            packageNames = null // null = ALL apps

            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC

            // 300ms mein ek baar event lo — battery optimize
            notificationTimeout = 300

            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
        }
        serviceInfo = info
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return

        when (event.eventType) {

            // App switch detect karna
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                val pkg = event.packageName?.toString() ?: return
                if (pkg != currentPackage) {
                    currentPackage = pkg
                    onAppSwitched(pkg)
                }
            }

            // Screen content change — text scan karo
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> {
                scanScreenForKeywords()
            }

            else -> { /* ignore */ }
        }
    }

    /**
     * Jab bhi app switch ho — log karo
     */
    private fun onAppSwitched(packageName: String) {
        // System apps ignore karo (optional)
        val systemPackages = listOf("com.android.systemui", "com.android.launcher")
        if (packageName in systemPackages) return

        // Ek hi app ko baar baar log mat karo
        if (packageName == lastLoggedPackage) return
        lastLoggedPackage = packageName

        serviceScope.launch {
            repository.insertLog(
                ActivityLog(
                    childId = childId,
                    type = "APP_USAGE",
                    title = "App Opened",
                    content = packageName,
                    extra = packageName,
                    timestamp = System.currentTimeMillis()
                )
            )
        }
    }

    /**
     * Screen pe saara visible text collect karo
     * aur dangerous keywords scan karo
     */
    private fun scanScreenForKeywords() {
        val rootNode = rootInActiveWindow ?: return
        val allText = extractTextFromNode(rootNode)

        if (allText.isBlank()) return

        val lowerText = allText.lowercase()

        for (keyword in dangerousKeywords) {
            if (keyword in lowerText) {
                logKeywordAlert(keyword, allText)
                break // Ek event mein ek alert kaafi hai
            }
        }

        rootNode.recycle()
    }

    /**
     * Accessibility tree se saara text extract karo
     */
    private fun extractTextFromNode(node: AccessibilityNodeInfo?): String {
        node ?: return ""
        val sb = StringBuilder()

        // Node ka apna text
        node.text?.let { sb.append(it).append(" ") }
        node.contentDescription?.let { sb.append(it).append(" ") }

        // Children ka text (recursive)
        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            sb.append(extractTextFromNode(child))
            child?.recycle()
        }

        return sb.toString()
    }

    /**
     * Dangerous keyword mila — DB mein alert log karo
     */
    private fun logKeywordAlert(keyword: String, context: String) {
        // Context truncate karo — sirf relevant part
        val truncated = if (context.length > 500) context.take(500) + "..." else context

        serviceScope.launch {
            repository.insertLog(
                ActivityLog(
                    childId = childId,
                    type = "KEYWORD_ALERT",
                    title = "⚠️ Dangerous Keyword Detected",
                    content = "Keyword: \"$keyword\"\n\nContext:\n$truncated",
                    extra = "SEVERITY:HIGH|APP:$currentPackage|KEYWORD:$keyword",
                    timestamp = System.currentTimeMillis()
                )
            )
        }
    }

    override fun onInterrupt() {
        // Service interrupt hui — cleanup
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceJob.cancel()
    }
}
