package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.ViewModelProvider
import coil.Coil
import coil.ImageLoader
import com.example.data.AppDatabase
import com.example.data.ParentControlRepository
import com.example.ui.AppIconFetcherFactory
import com.example.ui.MainScreen
import com.example.ui.ParentControlViewModel
import com.example.ui.ParentControlViewModelFactory
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.SpaceBlack

class MainActivity : ComponentActivity() {
    private lateinit var viewModel: ParentControlViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // 1. Coil ko configure karo — real app icons ke liye
        val imageLoader = ImageLoader.Builder(this)
            .components {
                // AppIconFetcherFactory register karo
                // Ab AsyncImage(AppIconFetcher(...)) seedha kaam karega
                add(AppIconFetcherFactory(this@MainActivity))
            }
            .build()
        Coil.setImageLoader(imageLoader)

        // 2. Initialize DB & Repository
        val database = AppDatabase.getDatabase(this)
        val repository = ParentControlRepository(database)

        // 3. Initialize ViewModel via Factory
        val factory = ParentControlViewModelFactory(repository)
        viewModel = ViewModelProvider(this, factory)[ParentControlViewModel::class.java]

        // 4. Render content
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = SpaceBlack
                ) {
                    MainScreen(viewModel = viewModel)
                }
            }
        }
    }
}
