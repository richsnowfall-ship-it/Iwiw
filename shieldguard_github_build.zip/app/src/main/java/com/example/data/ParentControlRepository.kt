package com.example.data

import kotlinx.coroutines.flow.Flow

class ParentControlRepository(private val database: AppDatabase) {
    private val activityLogDao = database.activityLogDao()
    private val deviceConfigDao = database.deviceConfigDao()
    private val screenshotLogDao = database.screenshotLogDao()
    private val childLocationDao = database.childLocationDao()

    // Activity Logs
    fun getLogsByChild(childId: String): Flow<List<ActivityLog>> = activityLogDao.getLogsByChild(childId)
    
    suspend fun insertLog(log: ActivityLog) = activityLogDao.insertLog(log)
    
    suspend fun clearLogsByChild(childId: String) = activityLogDao.clearLogsByChild(childId)
    
    suspend fun deleteLogBy(id: Int) = activityLogDao.deleteLogById(id)

    // Device Config
    fun getConfigByChild(childId: String): Flow<DeviceConfig?> = deviceConfigDao.getConfigByChild(childId)
    
    suspend fun getConfigDirect(childId: String): DeviceConfig? = deviceConfigDao.getConfigDirect(childId)
    
    suspend fun insertOrUpdateConfig(config: DeviceConfig) = deviceConfigDao.insertOrUpdateConfig(config)

    // Screenshot Logs
    fun getScreenshotsByChild(childId: String): Flow<List<ScreenshotLog>> = screenshotLogDao.getScreenshotsByChild(childId)
    
    suspend fun insertScreenshot(screenshot: ScreenshotLog) = screenshotLogDao.insertScreenshot(screenshot)
    
    suspend fun clearScreenshots(childId: String) = screenshotLogDao.clearScreenshots(childId)

    // Location Logs
    fun getLocationsByChild(childId: String): Flow<List<ChildLocation>> = childLocationDao.getLocationsByChild(childId)
    
    suspend fun insertLocation(location: ChildLocation) = childLocationDao.insertLocation(location)
    
    suspend fun getLatestLocation(childId: String): ChildLocation? = childLocationDao.getLatestLocation(childId)
}
