package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ActivityLogDao {
    @Query("SELECT * FROM activity_logs ORDER BY timestamp DESC")
    fun getAllLogs(): Flow<List<ActivityLog>>

    @Query("SELECT * FROM activity_logs WHERE childId = :childId ORDER BY timestamp DESC")
    fun getLogsByChild(childId: String): Flow<List<ActivityLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: ActivityLog)

    @Query("DELETE FROM activity_logs WHERE childId = :childId")
    suspend fun clearLogsByChild(childId: String)

    @Query("DELETE FROM activity_logs WHERE id = :id")
    suspend fun deleteLogById(id: Int)
}

@Dao
interface DeviceConfigDao {
    @Query("SELECT * FROM device_configs WHERE childId = :childId LIMIT 1")
    fun getConfigByChild(childId: String): Flow<DeviceConfig?>

    @Query("SELECT * FROM device_configs WHERE childId = :childId LIMIT 1")
    suspend fun getConfigDirect(childId: String): DeviceConfig?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateConfig(config: DeviceConfig)
}

@Dao
interface ScreenshotLogDao {
    @Query("SELECT * FROM screenshot_logs WHERE childId = :childId ORDER BY timestamp DESC")
    fun getScreenshotsByChild(childId: String): Flow<List<ScreenshotLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScreenshot(screenshot: ScreenshotLog)

    @Query("DELETE FROM screenshot_logs WHERE childId = :childId")
    suspend fun clearScreenshots(childId: String)
}

@Dao
interface ChildLocationDao {
    @Query("SELECT * FROM child_locations WHERE childId = :childId ORDER BY timestamp DESC")
    fun getLocationsByChild(childId: String): Flow<List<ChildLocation>>

    @Query("SELECT * FROM child_locations WHERE childId = :childId ORDER BY timestamp DESC LIMIT 1")
    suspend fun getLatestLocation(childId: String): ChildLocation?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLocation(location: ChildLocation)
}
