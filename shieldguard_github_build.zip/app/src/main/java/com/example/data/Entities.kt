package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "activity_logs")
data class ActivityLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val childId: String,
    val type: String, // "CALL", "SMS", "KEYSTROKE", "APP_USAGE", "NOTIFICATION", "KEYWORD_ALERT"
    val title: String, // Contact Name, App Name, Sender, etc.
    val content: String, // Body of message, text typed, duration etc.
    val extra: String = "", // Caller number, package name, severity level, etc.
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "device_configs")
data class DeviceConfig(
    @PrimaryKey val childId: String,
    val isPhoneLocked: Boolean = false,
    val lockedApps: String = "", // Comma-separated list of locked app names/packages (e.g., "YouTube,WhatsApp")
    val isInternetBlocked: Boolean = false,
    val geofenceLat: Double = 28.6139, // Default: New Delhi Lat
    val geofenceLng: Double = 77.2090, // Default: New Delhi Lng
    val geofenceRadius: Float = 500f, // in meters
    val lastActiveTime: Long = System.currentTimeMillis()
)

@Entity(tableName = "screenshot_logs")
data class ScreenshotLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val childId: String,
    val imageData: String, // Base64 or a structured layout mock string
    val timestamp: Long = System.currentTimeMillis(),
    val appName: String = "Home Screen"
)

@Entity(tableName = "child_locations")
data class ChildLocation(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val childId: String,
    val latitude: Double,
    val longitude: Double,
    val timestamp: Long = System.currentTimeMillis(),
    val isOutsideSafeZone: Boolean = false
)
